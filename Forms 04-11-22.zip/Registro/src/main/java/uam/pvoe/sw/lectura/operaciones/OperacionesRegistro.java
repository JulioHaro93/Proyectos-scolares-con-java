/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uam.pvoe.sw.lectura.operaciones;

import uam.pvoe.sw.lectura.clases.Persona;

/**
 *
 * @author ALUMNA16
 */
public class OperacionesRegistro {
    
    Persona pe = new Persona();
    /*Metodo que valide que el rfc tenga 10 digitos, si los tiene va a registrar a la persona y al hacerlo imprime por consola,
    
    en caso contrario imprimir "Error en RFC"*/
    
    public boolean rfcTester(){
    
        boolean respuesta = false;
        
        return respuesta;
    
    
    }
    
}
