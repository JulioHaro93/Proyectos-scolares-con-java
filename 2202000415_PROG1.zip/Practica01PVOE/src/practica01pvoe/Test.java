/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica01pvoe;

/**
 *
 * @author Haro Capetillo Julio Cesar, 2202000415, programa 1.
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Monticulo m = new Monticulo();
        m.rellenaTerrenos();
        m.imprimeTerrenos();
        m.cuentaFlores();
        m.calGanPorTipo();
    }
    
}
