/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import datos.OperacionBD;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.util.ArrayList;
/**
 *
 * @author Alumno
 */
public class Banco extends OperacionBD {
    
    
    public Banco() {
        
    }
    
    public String calcularPromedio() throws SQLException{
        
        OperacionBD ap = new OperacionBD();
        ArrayList b =  ap.listaAzcSuc();
        ArrayList a = ap.consultarCuentas();
        double numero = a.size();
        
        double promedio =0;
        double sumadorAZC =0;
        double sumadorCua =0;
        double sumadorXoc=0;
        double divisor = (double)a.size();
        
        System.out.println("Banco Lista"+ divisor);
        
        return "Banco Lista"+  divisor;
}    
     
    public void cuentaSucursal(){
        
       
    }
    
    
    
    
}
