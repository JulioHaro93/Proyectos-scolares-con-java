/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import datos.OperacionBD;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Banco;

/**
 *
 * @author Alumno
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws SQLException {
        OperacionBD op= new OperacionBD();
        Banco banc = new Banco();

        System.out.println(op.conectar());
        try {
            System.out.println(op.consultarCuentas());
        } catch (SQLException ex) {
            System.out.println("error 1" + ex.getMessage());
        }
        
        try {
            ArrayList op1 = op.consultarCuentas();
        } catch (SQLException ex) {
            System.out.println("Error 1" + ex.getMessage());
        }
        
        
        System.out.println(banc.calcularPromedio());
    }
    
    
    
    
}
