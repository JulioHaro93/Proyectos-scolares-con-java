/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.Cuenta;

/**
 *
 * @author Alumno
 */
public class OperacionBD {
    
    private static final String USUARIO="root";
    private static final String CONTRA="sasa";
    private static final String BD="empresas";
    private static final String URL="jdbc:mysql://localhost:3306/";
    private Connection conexion;
    
    public boolean conectar(){
        boolean estado=false;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion=DriverManager.getConnection(URL+BD, USUARIO, CONTRA);
            if(conexion!=null)
                estado=true;
        } catch (ClassNotFoundException ex) {
            System.out.println("Error 1"+ex.getMessage());
        } catch (SQLException ex) {
           System.out.println("Error 2"+ex.getMessage());
        }
        return estado;
   
    }
    
        public void desconectar(){
        try {
            conexion.close();
        } catch (SQLException ex) {
            System.out.println("Error 1"+ex.getMessage());
        }
    }
        
        public ArrayList<Cuenta> consultarCuentas() throws SQLException{
        ArrayList<Cuenta> cuentas= new ArrayList<>();
        String query="SELECT * FROM sucursales";
        Statement sentencia= conexion.createStatement();
        try{
            ResultSet rs;
            rs=sentencia.executeQuery(query);
            while(rs.next()){
                Cuenta cn= new Cuenta();
                cn.setNumCuenta(rs.getString("numCuenta"));
                cn.setNombreCuentahabiente(rs.getString("nombreCuentahabiente"));
                cn.setSaldo(rs.getDouble("saldo"));
                cn.setSucursalApertura(rs.getString("sucursalApertura"));
                cuentas.add(cn);
                
            }         
        }   catch(SQLException ex){
                System.out.println("Error 1" + ex.getMessage());
                }
        return cuentas;
        
}
        
        public ArrayList<Cuenta> listaAzcSuc() throws SQLException {
        ArrayList<Cuenta> cuentas= new ArrayList<>(); 
        String query="SELECT saldo FROM sucursales WHERE sucursalApertura = 'AZC'";
        Statement sentencia= conexion.prepareStatement(query);
        try{
            //PreparedStatement sentencia= conexion.prepareStatement(query);
            ResultSet rs;
            rs=sentencia.executeQuery(query);
            while(rs.next()){
                Cuenta cn= new Cuenta();
                cn.setSaldo(rs.getDouble("saldo"));
                //cn.setSucursalApertura(rs.getString("sucursalApertura"));
                cuentas.add(cn);
                
            }         
        }   catch(SQLException ex){
                System.out.println("Error 1" + ex.getMessage());
                }
        return cuentas;
    }
        
        /*
        public boolean agregarCuenta(Cuenta cuenta){
        boolean estado = false ;
        Statement consultaSQL;
        String q ="INSERT INTO alumnos VALUES("+"'"+ alumno.getMatricula() +"',"+"'"+alumno.getNombre()+"',"+alumno.getEdad()+")";
        try {
            consultaSQL = conexion.createStatement();
            consultaSQL.execute(q);
            estado=true;
        } catch (SQLException ex) {
            System.out.println("Error 1"+ex.getMessage());
        }
           
        
        return estado;
    }
        */
    
    
}
    
    


